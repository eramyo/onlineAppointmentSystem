from tkinter import CASCADE
from django.db import models
from django.contrib.auth.models import AbstractUser
from django.contrib.auth.models import UserManager
import datetime
from matplotlib import widgets

from matplotlib.widgets import Widget
from pytz import timezone


class User(AbstractUser):
    type_choices = (
        ('M', 'Moderator'),
        ('D', 'Doctor'),
        ('C', 'Client')
    )
    user_type = models.CharField('Type', max_length=1, choices=type_choices, default='C')
    email = models.EmailField(unique=True)
    first_name = models.CharField('First name', max_length=50)
    last_name = models.CharField('Last name', max_length=50)

    def __str__(self):
        return "%s %s" % (self.first_name, self.last_name)

    def get_absolute_url(self):
        return '/%i' % self.pk

    def get_full_name(self):
        return '%s %s' % (self.first_name, self.last_name)


    def is_doctor(self):
        """Return True if User is Doctor, else False"""
        return self.user_type == 'D'

    def is_moderator(self):
        """Return True if User is Moderator, eld False"""
        return self.user_type == 'M'

    def is_customer(self):
        return self.user_type == 'C'

class ClientManager(UserManager):
    def get_queryset(self):
        return super().get_queryset().filter(user_type='C')

class ModeratorManager(UserManager):
    def get_queryset(self):
        return super().get_queryset().filter(user_type='M')


class DoctorManager(UserManager):
    def get_queryset(self):
        return super().get_queryset().filter(user_type='D')


class Notification(models.Model):
    title = models.CharField(max_length=200)
    message = models.CharField(max_length=200)
    timestamp = models.TimeField(auto_now_add=True)
    class Meta:
        ordering = ['timestamp']

class Moderator(User):
    objects = ModeratorManager()

    class Meta:
        ordering = ['last_name']

    def __str__(self):
        return "%s %s" % (self.first_name, self.last_name)

    def save(self, *args, **kwargs):
        if not self.pk:
            self.user_type = 'M'
        return super().save(*args, **kwargs)

    def get_full_name(self):
        return '%s %s' % (self.first_name, self.last_name)


class Client(User):
    objects = ClientManager()

    gender_choices = (
        ('M', 'Male'),
        ('F', 'Female'),
        
    )
    gender = models.CharField('Gender', max_length=1, choices = gender_choices, default='M')
    dob = models.DateField()
    address = models.CharField(max_length=200)
    phone = models.CharField(max_length=200,null=True)
    notification = models.ForeignKey(Notification,on_delete=models.CASCADE, null=True)

    class Meta:
        ordering = ['last_name']

    def __str__(self):
        return "%s %s" % (self.first_name, self.last_name)

    def save(self, *args, **kwargs):
        if not self.pk:
            self.user_type = 'C'
        return super().save(*args, **kwargs)

    def get_full_name(self):
        return '%s %s' % (self.first_name, self.last_name) 



class Doctor(User):
    objects = DoctorManager()
    specialization = models.CharField('Specialization', max_length=50)
    phone = models.CharField(max_length=200, null=True)
    info = models.TextField('Information', max_length=1250, blank=True)
    myclient = models.ForeignKey(Client,on_delete=models.CASCADE,null=True)
    notifications = models.ForeignKey(Notification,on_delete=models.CASCADE,null=True)

    class Meta:
        ordering = ['specialization', 'last_name']

    def __str__(self):
        return "%s %s" % (self.first_name, self.last_name)

    def save(self, *args, **kwargs):
        if not self.pk:
            self.user_type = 'D'
        return super().save(*args, **kwargs)

    def get_absolute_url(self):
        # return f'/{self.pk}'
        return '/%i' % self.pk

    def get_full_name(self):
        return '%s %s' % (self.first_name, self.last_name)



class Service(models.Model):
    type = models.CharField(max_length=200)
    info = models.CharField(max_length=200)
    days = models.CharField(max_length=200)
    working_hours = models.CharField(max_length=200)
    pic = models.FileField(null=True,upload_to='static/images/uploads')
    doctor =models.ForeignKey(Doctor,on_delete=models.CASCADE)
    class Meta:
        ordering = ['type']
    def __str__(self) -> str:
        return self.type


class Appointment(models.Model):
    start_time = models.TimeField('Start time',null=True)
    end_time = models.TimeField('End time',null=True)
    date = models.DateField('Date')
    issue = models.CharField(max_length=200, null=True)
    client = models.ForeignKey(Client, on_delete=models.SET_NULL, null=True)
    doctor = models.ForeignKey(Doctor, on_delete=models.CASCADE)
    status = models.CharField(max_length=200,default='pending...')

    class Meta:
        ordering = ['start_time']

    def __str__(self):
        return str(self.start_time)

    def get_absolute_url(self):
        return f'/{self.doctor.id}/appoint/{self.id}'


    
    
