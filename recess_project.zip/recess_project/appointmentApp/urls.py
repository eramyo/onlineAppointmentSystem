from django.urls import URLPattern,path
from .views import *

urlpatterns = [
  path('', index, name='index' ),
  # path('add',registration, name='add'),
  path('clients', get_clients, name='clients'),
  path('doctors',all_doctors, name = 'all_doctors'),
  path('auth/register_doctor',register_doctor, name='register'),
  path('auth/register_reception',register_moderator, name='register_recep'),
  path('auth/register/user',register_User, name='register_user'),
  path('auth/login',my_login, name='login'),
  path('logout', log_out, name='logout'),
  path('appointment/<int:id>/',appoint_detail, name='appoint_detail'),
  path('doctor_appointments/<int:id>/',doctors_appoint,name='doctor_appoint'),
  path('add/service',getService, name='addservice')
   
]