from django.shortcuts import render,get_object_or_404
from django.shortcuts import redirect
from .forms import RegisterDoctorUserForm, ServiceForm, RegisterClientUserForm, LoginForm
from .forms import RegisterModeratorUserForm
from django.http import Http404
from django.contrib.auth.models import Group
from django.contrib.auth import authenticate,login,logout
from django.contrib.auth.forms import AuthenticationForm
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from .models import *



# moderaters views
@login_required(login_url='login')
def index(request):
    appointments = Appointment.objects.all()
    pending_count = Appointment.objects.filter(status = 'pending...').count()
    canceled_count = Appointment.objects.filter(status= 'Declined').count()
    service_count = Service.objects.all().count()
    context = {
        'appointments':appointments,
        'pending':pending_count,
        'cancelled':canceled_count,
        'services':service_count
    }
    return render(request, 'pages/index.html',context)

# @login_required(login_url='login')
# def registration(request):
    
#     appointment = Appointment()

#     if request.method == 'POST':

#         first_name = request.POST.get('first_name')
#         last_name = request.POST.get('last_name')
#         gender = request.POST.get('gender')
#         phone = request.POST.get('phone')
#         dob = request.POST.get('dob')
#         address = request.POST.get('address')
#         issue = request.POST['issue']
#         doctor = request.POST.get('doc')
#         start_time = request.POST['start_time']
#         end_time = request.POST['end_time']
#         date = request.POST['date']
#         save = request.POST['save']

#         if save == 'new':
#             #get or create a client
#             client, created = Client.objects.get_or_create(
#                 first_name=first_name,
#                 last_name=last_name,
#                 phone=phone,
#                 defaults={
#                     'gender':gender,
#                     'dob':dob,
#                     'address':address
#                 }
#             )
#             appointment.issue = issue
#             appointment.doctor = Doctor.objects.get(phone=doctor)
#             appointment.start_time= start_time
#             appointment.end_time = end_time
#             appointment.date = date
#             appointment.client = client
#             appointment.save()
#         elif save =='exists':
#             client_id = request.POST['client']
#             appointment.doctor = Doctor.objects.get(id=doctor)
#             appointment.client = Client.objects.get(id=client_id)
#             appointment.start_time= start_time
#             appointment.end_time = end_time
#             appointment.date = date
#             appointment.issue = issue
#             appointment.save()

#     clients = Client.objects.all()
#     doctors = Doctor.objects.all()
#     context = {
#         'doctors':doctors,
#         'clients':clients
#     }
#     return render(request,'pages/registration.html',context)

@login_required(login_url='login')
def get_clients(request):
    clients = Client.objects.all()
    context = {'clients':clients}
    return render(request,'pages/clients.html',context)

@login_required(login_url='login')
def all_doctors(request):
    doctors = Doctor.objects.all()
    context = {
        'doctors':doctors
    }
    return render(request,'pages/admin_doctors.html',context)

@login_required(login_url='login')
def appoint_detail(request,id):
    appoint = get_object_or_404(Appointment,id=id)
    context = {
        'appoint':appoint
    }
    return render(request,'pages/appointment_detail.html',context)

@login_required(login_url='login')
def doctors_appoint(request,id):
    doctor = Doctor.objects.get(id=id)
    appointments = doctor.appointment_set.all()
    context = {
        'appointments':appointments,
        'doctor':doctor
    }
    return render(request,'pages/doctor_appointments.html',context)

@login_required(login_url='login')
def getService(request):
    if request.method == 'POST':
        service = ServiceForm(request.POST,request.FILES)
        if service.is_valid():
            service.save()
            return redirect('addservice')
    else:
        service = ServiceForm()
    return render(request,'pages/registration.html',{'form':service})

@login_required(login_url='login')
def service_details(request):
    return render(request,'pages/service_details.html')




################### AUTHENTICATIONS ##############



def register_doctor(request):
    if request.method == 'POST':
        form = RegisterDoctorUserForm(request.POST)
        if form.is_valid():
            new_doctor = form.save()
            login(request,new_doctor)
            return redirect('doctor_index')
        else:
            print(form.errors.as_data)
            raise Http404('Form is not valid')
    else:
        form = RegisterDoctorUserForm()

    return render(request, 'registration/doctor_register.html', {'form': form})


def register_moderator(request):
    if request.method == 'POST':
        form = RegisterModeratorUserForm(request.POST)
        if form.is_valid():
            new_moderator = form.save()
            login(request,new_moderator)
            return redirect('index')
        else:
            print(form.errors.as_data)
            #raise Http404('Form is not valid')
    else:
        form = RegisterModeratorUserForm()

    return render(request, 'registration/moderator_form.html', {'form': form, 'user_type': 'Moderator'})

def register_User(request):
    if request.method == 'POST':
        user_form = RegisterClientUserForm(request.POST)
        if user_form.is_valid():
            new_user = user_form.save()
            login(request,new_user)
            return redirect('user_index')
        else:
            print(user_form.errors.as_data)
            raise Http404('Form is not valid')
    else:
        user_form = RegisterClientUserForm()

    return render(request, 'registration/user_registration.html', {'form': user_form})


def my_login(request):
    if request.method == 'POST':
        form = LoginForm(request,data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username,password=password)
            if user is not None:
                login(request,user)
                messages.info(request,f"welcome {username}")
                if request.user.user_type == 'M':
                    return redirect('index')
                elif request.user.user_type == 'D':
                    return redirect('doctor_index')
                elif request.user.user_type == 'C':
                    return redirect('user_index')
            else:
                print(form.errors.as_data)
                messages.error(request,"invalid username or password")
        else:
            print(form.errors.as_data)
            messages.error(request,"invalid username or password")
    
    form = LoginForm()
    return render(request,'registration/login.html',context={'login_form':form})
    

def log_out(request):
    logout(request)
    return redirect('login') 