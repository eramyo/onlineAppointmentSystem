from .models import Appointment, Service
from django import forms


class AppointmentCreateFormDoctor(forms.ModelForm):
    class Meta:
        model = Appointment
        fields = ['start_time', 'end_time', 'date','client']


class AppointmentCreateFormModerator(forms.ModelForm):
    class Meta:
        model = Appointment
        fields = ['doctor', 'start_time', 'end_time', 'date','client','issue']


class AppointmentCreateFewForm(forms.ModelForm):
    begin_time = forms.TimeField(required=True)
    finish_time = forms.TimeField(required=True)
    duration = forms.TimeField(required=True)

    class Meta:
        model = Appointment
        fields = ['doctor', 'date']

################ AUTH FORMS ####################

from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from appointmentApp.models import Doctor
from appointmentApp.models import Moderator
from appointmentApp.models import Client


class RegisterDoctorUserForm(UserCreationForm):
    class Meta:
        model = Doctor
        fields = ['email', 'username', 'first_name', 'last_name','phone', 'specialization', 'password1', 'password2']


class RegisterModeratorUserForm(UserCreationForm):
    class Meta:
        model = Moderator
        fields = ['email', 'username', 'first_name', 'last_name','user_type', 'password1', 'password2']


class RegisterClientUserForm(UserCreationForm):
    class Meta:
        model = Client
        fields = ['email', 'username', 'first_name', 'last_name','dob', 'gender', 'phone', 'address', 'user_type', 'password1', 'password2']

class LoginForm(AuthenticationForm):
    username = forms.CharField(label='Email')

class ServiceForm(forms.ModelForm):
    class Meta:
        model = Service
        fields = ['type','info','days','working_hours', 'doctor', 'pic']

class AppointmentForm(forms.ModelForm):
    class Meta:
        model = Appointment
        fields = ['date','issue','doctor','status','client']