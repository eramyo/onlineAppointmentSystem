from django.shortcuts import redirect, render
from appointmentApp.models import *
from django.contrib.auth.decorators import login_required
from django.template.loader import render_to_string
from django.core.mail import send_mail

@login_required(login_url='login')
def index(request):
    doctor = Doctor.objects.get(id=request.user.id)
    appointments = doctor.appointment_set.all()
    pending = Appointment.objects.filter(doctor=doctor,status='pending...').count()
    cancelled = Appointment.objects.filter(doctor=doctor,status='Declined').count() 
    approved = Appointment.objects.filter(doctor=doctor,status='Approved').count()
    context = {
        'appointments':appointments,
        'pending':pending,
        'cancelled':cancelled,
        'approved':approved
    }
    print(doctor)
    return render(request,'pages/doctor_index.html',context)

@login_required(login_url='login')
def clients(request):
    doctor = Doctor.objects.get(id=request.user.id)
    appoint = Appointment.objects.filter(doctor=doctor).all()
    print(appoint)
    return render(request,'pages/doc_calender.html',{'appoints':appoint})

@login_required(login_url='login')
def recent(request):
    return render(request,'pages/recent.html')

@login_required(login_url='login')
def approve(request,appoint_id):

    appointment = Appointment.objects.get(id=appoint_id)
    appointment.status = 'Approved'
    appointment.save()

    notification = Notification()
    notification.title = 'Appoinment Approved'
    notification.message = 'Your appointment has been approved, You will see the doctor'
    notification.save()
    client = appointment.client
    client.notification = notification
    doctor = Doctor.objects.get(id=request.user.id)
    client.save()
    client = appointment.client
    appointment.save()
    c = Client.objects.get(id = client.id)
    
    print(c.first_name)
    html = render_to_string('pages/message.html', {
                'client':c.first_name,
                'status':appointment.status,
                'doctor':doctor.first_name,
                'time': appointment.start_time
            })
    
    send_mail('Appointment','Your appointment has been Approved', 'odokonyerogerald@gmail.com',[c.email],html_message=html)

    
 
    
    return redirect('doctor_index')

def cancel(request,appoint_id):
     appointment = Appointment.objects.get(id=appoint_id)
     appointment.status = 'Declined'
     appointment.save()

     notification = Notification()
     notification.title = 'Appoinment in Que'
     notification.message = 'Your appointment has being processed'
     notification.save()
     client = appointment.client
     client.notification = notification
     client.save()
     return redirect('doctor_index')

def doctor_profile(request,id):
    doctor = Doctor.objects.get(id=request.user.id)
    return render(request,'pages/profile.html',{'doctor':doctor})
    
   