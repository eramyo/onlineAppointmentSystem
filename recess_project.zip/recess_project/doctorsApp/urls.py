from unicodedata import name
from django.urls import URLPattern, path
from .views import *

urlpatterns =[
    path('',index,name ='doctor_index'),
    path('clients', clients, name = 'client_doc'),
    path('appointment_history',recent,name='recent'),
    path('approve/<int:appoint_id>/',approve, name='approve'),
    path('decline/<int:appoint_id>/',cancel, name='decline'),
    path('profile/<int:id>/',doctor_profile, name='doc_profile')
]