from django.shortcuts import render
from django.shortcuts import redirect
from .forms import RegisterDoctorUserForm
from .forms import RegisterModeratorUserForm
from django.http import Http404
from django.contrib.auth.models import Group
from django.contrib.auth import authenticate,login,logout
from django.contrib.auth.forms import AuthenticationForm
from django.contrib import messages



def register_doctor(request):
    if request.method == 'POST':
        form = RegisterDoctorUserForm(request.POST)
        if form.is_valid():
            new_doctor = form.save()
            group_doctor = Group.objects.get(name='DoctorGroup')   
            new_doctor.groups.add(group_doctor)
            return redirect('index')
        else:
            raise Http404('Form is not valid')
    else:
        form = RegisterDoctorUserForm()

    return render(request, 'userauth/doctor_register.html', {'form': form, 'user_type': 'Doctor'})


def register_moderator(request):
    if request.method == 'POST':
        form = RegisterModeratorUserForm(request.POST)
        if form.is_valid():
            new_moderator = form.save()
            group_doctor = Group.objects.get(name='DoctorGroup')        # May not working if group has another name
            group_moderator = Group.objects.get(name='ModeratorGroup')  # May not working if group has another name
            new_moderator.groups.add(group_doctor)
            new_moderator.groups.add(group_moderator)
            return redirect('index')
        else:
            print(form.errors.as_data)
            #raise Http404('Form is not valid')
    else:
        form = RegisterModeratorUserForm()

    return render(request, 'userauth/register.html', {'form': form, 'user_type': 'Moderator'})


def my_login(request):
    if request == 'POST':
        form = AuthenticationForm(request,data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username,password=password)
            if user is not None:
                login(request,user)
                messages.info(request,f"welcome {username}")
                return redirect('index')
            else:
                messages.error(request,"invalid username or password")
        else:
            messages.error(request,"invalid username or password")
    
    form = AuthenticationForm
    return render(request,'registration/login.html',context={'login_form':form})
    

def log_out(request):
    logout(request)
    return redirect('userauth/login.html')