from django.contrib.auth.forms import UserCreationForm
from appointmentApp.models import Doctor
from appointmentApp.models import Moderator


class RegisterDoctorUserForm(UserCreationForm):
    class Meta:
        model = Doctor
        fields = ['username', 'first_name', 'last_name','phone', 'specialization', 'password1', 'password2']


class RegisterModeratorUserForm(UserCreationForm):
    class Meta:
        model = Moderator
        fields = ['username', 'first_name', 'last_name', 'password1', 'password2']
