from unicodedata import name
from django.urls import URLPattern,path
from .views import *

urlpatterns = [
    path('register',register_doctor,name='register'),
    path('login',my_login, name='login')
]