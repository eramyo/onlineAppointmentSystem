from django.shortcuts import render
from django.test import client
from appointmentApp.models import *
from django.contrib.auth.decorators import login_required
from django.shortcuts import render,get_object_or_404

from appointmentApp.forms import AppointmentForm

def user_index(request):
    user = Client.objects.get(id=request.user.id)
    notification = Client.objects.filter(id=request.user.id)
    appointments = Appointment.objects.filter(client=user).all()
    pending = Appointment.objects.filter(client=user,status='pending...').count()
    cancelled = Appointment.objects.filter(client=user,status='Declined').count() 
    approved = Appointment.objects.filter(client=user,status='Approved').count()
    context = {
        'appointments':appointments,
        'notification':notification,
        'pending':pending,
        'cancelled':cancelled,
        'approved':approved
        }
    
    
    return render(request,'pages/user_index.html',context)

def service(request):
    services= Service.objects.all()
    context = {
        'services':services
    }
    return render(request,'pages/services.html',context)

def service_details(request, service_id):
    service = get_object_or_404(Service,id=service_id)
    return render(request,'pages/service_details.html',{'service':service})

def book_appoint(request):
    doctors = Doctor.objects.all()
    appointment = Appointment()
    if request.method == 'POST':
        date = request.POST['date']
        start_time = request.POST['start_time']
        issue = request.POST['issue']
        doctor = Doctor.objects.get(id=request.POST['doctor'])
        client = Client.objects.get(id=request.user.id)

        appointment.date = date
        appointment.start_time=start_time
        appointment.issue = issue
        appointment.doctor = doctor
        appointment.client = client
        appointment.save()
    
    return render(request,'pages/book_appoint.html',{'doctors':doctors})

def get_doctors(request):
    doctors = Doctor.objects.all()
    return render(request,'pages/docs.html',{'doctors':doctors})    


@login_required(login_url='login')
def appoint_detail(request,id):
    appoint = get_object_or_404(Appointment,id=id)
    context = {
        'appoint':appoint
    }
    return render(request,'pages/appoint_detail.html',context)


def user_profile(request,id):
    client = Client.objects.get(id=request.user.id)
    return render(request,'pages/profile.html',{'client':client})
    