from unicodedata import name
from django.urls import URLPattern,path
from .views import *

urlpatterns = [
    path('index',user_index, name='user_index'),
    path('service',service , name='services'),
    path('service/details/<int:service_id>/',service_details, name='service_details'),
    path('book',book_appoint,name='book'),
    path('doctors',get_doctors, name='get_docs'),
    path('appointment/<int:id>/',appoint_detail, name='appoint_details'),
]
